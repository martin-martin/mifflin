import webbrowser


def main():
    """TODO: implement this"""
    URL = 'https://en.wikipedia.org/wiki/The_Office_(American_TV_series)'
    webbrowser.open_new_tab(URL)
    print('more mifflin to come...')


if __name__ == "__main__":
    main()
